#include<stdlib.h>

int main() { 
    int*x = malloc(sizeof(int)); 
    exit(0); 
    return 0; 
}
