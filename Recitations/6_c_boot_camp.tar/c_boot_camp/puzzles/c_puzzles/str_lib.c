#include <stdio.h>
#include <string.h>

/* For all these problems, you may not use any 
 * string library functions; you may, however, 
 * define any helper functions that you may need */ 

/* Concatenates the src string to the end of the dest
 * string, returns the dest string
 *
 * You can assume that src/dest are '\0' terminated, 
 * that dest hold enough space to store src+dest and 
 * src/dest do not overlap in memory */
char* strcat_m(char* dest, char* src) { 
    /* TODO: Implement this function */
    return NULL; 
}

/* Reverses a string and returns the a new string 
 * containing the reversed string 
 *
 * You can assume that str is '\0' terminated */
char* strrev(char *str) {
    /* TODO: Implement this function */

    return NULL; 
}

int main()
{
    /* TODO: Implement test cases to check your implemenation
     * You MAY use string library functions to test your code */
    return 0;
}
